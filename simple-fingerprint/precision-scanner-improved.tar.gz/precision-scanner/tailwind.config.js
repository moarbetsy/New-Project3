/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0f172a',      // Slate 900
        card: '#1e293b',    // Slate 800
        border: '#334155',  // Slate 700
        text: '#f8fafc',    // Slate 50
        subtext: '#94a3b8', // Slate 400
        accent: '#06b6d4',  // Cyan 500
        success: '#22c55e', // Green 500
        danger: '#ef4444',  // Red 500
        warn: '#f59e0b',    // Amber 500
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-fast': 'pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
    },
  },
  plugins: [],
};
