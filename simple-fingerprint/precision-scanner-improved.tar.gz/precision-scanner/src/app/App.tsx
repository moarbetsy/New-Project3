import { useCallback } from 'react';
import { useInitialize } from '@/hooks/useInitialize';
import { useAppStore } from './store';
import { StatusBadge, Box } from '@/components/ui';
import { NetworkCard } from '@/features/network/components/NetworkCard';
import { HardwareCard } from '@/features/fingerprint/components/HardwareCard';
import { EntropyCard } from '@/features/fingerprint/components/EntropyCard';

/**
 * Main App component
 * Root component for the Precision Scanner application
 */
export function App() {
  const { network, fingerprint, loading, initializeScan } = useAppStore();

  const initialize = useCallback(() => {
    initializeScan();
  }, [initializeScan]);

  useInitialize(initialize);

  return (
    <div className="min-h-screen bg-grid font-sans text-text p-4 md:p-8 flex justify-center">
      <div className="w-full max-w-5xl space-y-6">
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-center pb-6 border-b border-border">
          <div className="flex items-center gap-4 mb-4 md:mb-0">
            <div
              className="p-3 bg-accent/10 rounded-lg border border-accent/20"
              aria-hidden="true"
            >
              <svg
                className="w-8 h-8 text-accent"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white">
                Device Fingerprint
              </h1>
              <p className="text-subtext font-medium">Precision Identity Scanner</p>
            </div>
          </div>
          <div className="flex gap-3">
            <StatusBadge label="Scanner" active={!loading} />
            <StatusBadge
              label="Network"
              active={network?.status !== 'Restricted'}
              warning={network?.status === 'Restricted'}
            />
          </div>
        </header>

        {/* Hero ID Section */}
        <section
          className="bg-card border border-border rounded-xl p-8 relative overflow-hidden shadow-lg"
          aria-labelledby="device-id-heading"
        >
          <div
            className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none"
            aria-hidden="true"
          />
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-center md:text-left">
              <div
                className="text-accent text-xs font-bold uppercase tracking-widest mb-2"
                id="device-id-heading"
              >
                Unique Device ID
              </div>
              <div className="text-4xl md:text-6xl font-mono font-bold text-white tracking-tighter">
                {loading ? 'CALCULATING...' : fingerprint?.visitorId || 'N/A'}
              </div>
              <div className="text-subtext text-xs mt-2 font-mono">
                HASH:{' '}
                {fingerprint
                  ? `${fingerprint.canvasId}.${fingerprint.audioId}`
                  : '...'}
              </div>
            </div>
            {!loading && fingerprint && (
              <div className="grid grid-cols-2 gap-4">
                <Box label="Confidence" value="99.9%" />
                <Box
                  label="Bot Check"
                  value={fingerprint.isBotDetected ? 'FAILED' : 'PASSED'}
                  color={fingerprint.isBotDetected ? 'text-danger' : 'text-success'}
                />
              </div>
            )}
          </div>
        </section>

        {/* Main Grid */}
        <main className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <NetworkCard data={network} loading={loading} />
          <HardwareCard data={fingerprint} loading={loading} />
          <EntropyCard data={fingerprint} loading={loading} />
        </main>
      </div>
    </div>
  );
}
